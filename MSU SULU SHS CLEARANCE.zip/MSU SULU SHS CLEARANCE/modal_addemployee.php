<div class="modal fade" id="myModal_emp" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">Add Employee</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<form action="admin1.php" method="POST">
						<div class="Id">
							<label>	Employee Id*</label>
							<input type="" class="form-control" name= "emp_id" placeholder="Employee Id" required>
						</div>
						<div class="emp_name">
							<label>	First Name*</label>
							<input class="form-control" name= "emp_name" placeholder="First Name" required>
						</div>
						<div class="username">
							<label>User Name</label>
							<input class="form-control" name= "username" placeholder="User Name" >
						</div>
						<div class="department">
							<label>Department*</label>
							<select name="department" class="form-control">
								<option>Oral Communication</option>
								<option>Physical Education and Health</option>
								<option>Philosophy</option>
								<option>21st-century Literature</option>
								<option>Earth and Life Science</option>
								<option>Social Science 1</option>
								<option>Humanities 1</option>
								<option>Elective 1</option>
								<option>Work Immersion</option>
							</select>
						</div>
						<div class="password">
							<label>Password*</label>
							<input class="form-control" name= "password" placeholder="Password" required>
						</div>
						
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
						<button type="submit" name="addemp" class="btn btn-primary">Save</button>
					</div>
				</form>	
			</div>
		</div>
	</div>
</div>