<div class="modal fade" id="edit<?php echo $value ['id']?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">Edit <?php echo $value['student_Fname']; ?> Profile</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<form action="../edit_faculty1.php" method="POST">
						<div class="Id">
							<input value = "<?php echo $value['student_id'];?>" type="hidden" class="form-control" name= "studentId" placeholder="Faculty Id" required>
							<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id" placeholder="Faculty Id" required>
						</div>
						<div class="firstname">
							<label>	First Name*</label>
							<input value = "<?php echo $value['student_Fname'];?>" class="form-control" name= "firstname" placeholder="First Name" required>
						</div>
						<div class="middlename">
							<label>Middle Name</label>
							<input value = "<?php echo $value['student_Mname'];?>" class="form-control" name= "middlename" placeholder="Middle Name" >
						</div>
						<div class="lastname">
							<label>Last Name*</label>
							<input value = "<?php echo $value['student_Lname'];?>" class="form-control" name= "lastname" placeholder="Last Name" required>
						</div>
						<div class="contactnumber">
							<label>Contact Number</label>
							<input value = "<?php echo $value['Contact_num'];?>" type="number" class="form-control" name= "contactnumber" placeholder="Contact Number">
						</div>
						<div class="email">
							<label>Email</label>
							<input value = "<?php echo $value['Email'];?>" class="form-control" name= "email" placeholder="Email">
						</div>
						<br>
						<div class="col-md-3 strand">
							<label>Strand</label>
							<select name="strand" class="form-control">
								<option><?php echo $value['strand'];?></option>
								<option>STEM 1</option>
								<option>STEM 2</option>
								<option>STEM 3</option>
								<option>STEM 4</option>
								<option>STEM 5</option>
								<option>GAS 1</option>
								<option>GAS 2</option>
								<option>GAS 3</option>
								<option>GAS 4</option>
								<option>GAS 5</option>
					
							</select>
						</div>
					<div class="modal-footer form-group">
						<div class="row">
							<br />
							<br />
							<button type="button" class="btn btn-danger " data-dismiss="modal"><i class="fa fa-close"></i>Close</button>
							<button type="submit"  class="btn btn-primary ">Save</button>
							 
						</div>
					</div>
				</form>	
			</div>
		</div>
	</div>
</div>