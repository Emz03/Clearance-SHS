<?php 
include 'connect.php';
$studentId = $_POST['studentId'];
$firstname = $_POST['firstname'];
$middlename = $_POST['middlename'];
$lastname = $_POST['lastname'];
$contactnumber = $_POST['contactnumber'];
$email = $_POST['email'];
$strand = $_POST['strand'];
$id = $_POST['id'];

$query = $conn->prepare("UPDATE student SET student_id = ?, student_Fname = ?, student_Mname = ?, student_Lname = ?, Contact_num = ?, Email = ?, strand = ? WHERE id = ?"); 	
$query->execute(array($studentId,$firstname,$middlename,$lastname,$contactnumber,$email,$strand,$id));
header('location:production/admin1.php');
?>