<?php
include 'connect.php';

if (isset($_POST['add'])){
	$studentId = $_POST['studentId'];
	$firstname = $_POST['firstname'];
	$middlename = $_POST['middlename'];
	$lastname = $_POST['lastname'];
	$contactnumber = $_POST['contactnumber'];
	$email = $_POST['email'];
	$strand = $_POST['strand'];

	$add = $conn->prepare("INSERT INTO student (student_id, student_Fname, student_Mname, student_Lname, Contact_num, Email, strand)
        VALUES (?,?,?,?,?,?,?) ");
	$add->execute(array($studentId, $firstname, $middlename, $lastname, $contactnumber, $email, $strand));

	 $a = $conn->lastInsertId();
	$add1 = $conn->prepare("INSERT INTO clearance (id) VALUES (?)");
	$add1->execute(array($a));
	
}
?>