<?php 
include 'session_dept.php';
include 'connect.php';
// $status = $_POST['status'];
$id = $_POST['id'];
$user_id = $_SESSION['id'];


if ($user_id == 6) {
	$query = $conn->prepare("UPDATE clearance SET is_librarian_approval = 1  WHERE id = ?"); 	
	$query->execute(array($id));
	header('location:production/designee.php');

}
else {
	$query = $conn->prepare("UPDATE clearance SET is_registrar_approval = 1 WHERE id = ?"); 	
	$query->execute(array($id));
	$sql = $conn->prepare("INSERT INTO cleared_student(id) VALUES (?) ");

	// $query1 = $conn->prepare($sql);
	$sql->execute(array($id));
	header('location:production/designee.php');
}
?>