<?php
$servername = "localhost";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$servername;dbname=shs_clearance_db", $username, $password);
    // Create a PDO object with the appropriate parameters to connect to the database.
    // Replace 'shs_clearance_db' with your actual database name.
    
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Set the error mode to exception, which means that PDO will throw exceptions for database errors.
}
catch(PDOException $e) {
    // If there's an exception (an error), it will be caught here, and you can handle the error.
    // Uncomment the following line to display the error message if needed.
    // echo "Connection failed: " . $e->getMessage();
}


?>