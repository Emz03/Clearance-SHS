<?php
include 'connect.php';

if (isset($_POST['addemp'])) {
    $emp_id = $_POST['emp_id'];
    $emp_name = $_POST['emp_name'];
    $username = $_POST['username'];
    $department = $_POST['department'];
    $password = $_POST['password'];

    // Insert data into the 'employee' table
    $addemp = $conn->prepare("INSERT INTO employee (emp_id, emp_name, username, department, password)
        VALUES (?, ?, ?, ?, ?)");
    $addemp->execute(array($emp_id, $emp_name, $username, $department, $password));

    // Get the last inserted ID from the 'employee' table
    $employeeId = $conn->lastInsertId();

    // Add a column to the 'clearance' table
    $columnName = "is_". $department."_approval"; // You can customize the column name as needed
    $addColumn = $conn->prepare("ALTER TABLE clearance ADD COLUMN $columnName int(1)");
    $addColumn->execute();

    // Insert data into the 'clearance' table with the new column
    $addClearance = $conn->prepare("INSERT INTO clearance (department, $columnName)
        VALUES (?, ?)");
    $addClearance->execute(array($department, 'your_value_here')); // Replace 'your_value_here' with the actual value for the new column
}
?>
