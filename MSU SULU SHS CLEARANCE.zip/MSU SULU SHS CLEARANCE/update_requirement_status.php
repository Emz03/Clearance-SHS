<?php 
include 'session_dept.php';
include 'connect.php';
// $status = $_POST['status'];
$a = $_POST['haydi'];
$user_id = $_SESSION['id'];

	$query = $conn->prepare("UPDATE requirementstatus NATURAL JOIN employee NATURAL JOIN student SET status = 1 WHERE id = $a AND emp_id = $user_id"); 	
	$query->execute(array($a,$user_id));
	header('location:production/designee.php');	
?>