<?php
include('connect.php');

$username = $_POST['username'];
$password = md5($_POST['password']);

$sql = "SELECT * FROM employee WHERE password = ? AND username = ?";
$query = $conn->prepare($sql);
$query->execute(array($password,$username));
$row = $query->fetch();
$count = $query->rowCount();

if ($count > 0){
	session_start();
	$_SESSION['id'] = $row['emp_id'];
	echo 1;
}else{
	echo 0;
}
?>