<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="stylesheet.css">
	<!-- icon -->
	<link rel="icon" href="images/school-logo.png" >
	<title>Mindanao State University-SULU</title>
	<style>
		.carousel-inner > .item > img,
		.carousel-inner > .item > a > img {
			width: 70%;
			margin: auto;
		}
	</style>
</head>
<?php include 'inc/config.php'; ?>