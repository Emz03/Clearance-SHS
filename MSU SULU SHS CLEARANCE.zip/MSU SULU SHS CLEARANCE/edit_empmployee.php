<?php
include 'connect.php';


	$emp_id = $_POST['emp_id'];
	$emp_name = $_POST['emp_name'];
	$username = $_POST['username'];
	$department = $_POST['department'];
	$password = $_POST['password'];

	$query  = $conn->prepare("INSERT INTO employee (emp_id, emp_name, username,department, password)
        VALUES (?,?,?,?) ");
	$query ->execute(array($emp_id, $emp_name, $username, $department, $password));
    header('location:production/admin1.php');

	


?>