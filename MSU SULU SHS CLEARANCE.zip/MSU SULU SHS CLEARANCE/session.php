<?php 
include('connect.php');
session_start();

if (!isset($_SESSION['id']) || ($_SESSION['id'] == '')){ ?>
	<script>
		window.location = 'index.php';
	</script>
	<?php
}

$session_id = $_SESSION['id'];

$sql = "SELECT * FROM student WHERE student_id = ? ";
$query = $conn->prepare($sql);
$query->execute(array($session_id));
$row = $query->fetch();

$name = $row['student_Fname']. " " . $row['student_Mname']. " " . $row['student_Lname'];
$pic = $row['student_picture'];
$sess_pass = $row['password'];
?>