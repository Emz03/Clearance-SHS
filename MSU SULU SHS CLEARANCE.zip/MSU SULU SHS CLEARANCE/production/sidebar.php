<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
	<div class="menu_section">
		<h3>General</h3>
		<ul class="nav side-menu">
			<li><a><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>
				<ul class="nav child_menu">
					<li><a href="faculty.php">Clearance Status</a></li>
					<!-- <li><a href="faculty_passrequirements.php">Pass Requirements</a></li> -->
					<li><a href="edit_picture.php">Edit Profile Picture</a></li>
				</ul>
			</li>
			<li><a><i class="fa fa-edit"></i> Employee's <span class="fa fa-chevron-down"></span></a>
				<ul class="nav child_menu">
					
					
					<li><a href="librarian.php">Librarian</a></li>
					<li><a href="registrar.php">Registrar</a></li>

			</li>
		</ul>
	</div>
</div> 