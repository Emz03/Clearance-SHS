<div class="modal fade" id="message">
	<div class="body">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		<h4 class="modal-title" id="myModalLabel">Create Notification</h4>
	</div>
</div>