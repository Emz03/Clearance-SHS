<div class="modal fade" id="change_pass" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="post" name="fchange_p">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title"> Admin Change password </h4>
					</div>
					<div class="modal-body">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<input type="password" class="form-control" name="old_pass1" placeholder="Type your current password">
								</div>
								<div class="form-group">
									<input type="password" class="form-control" name="new_pass1" placeholder="Type your new password">
								</div>
								<div class="form-group">
									<input type="password" class="form-control" name="conf_pass1" placeholder="Confirm new password">
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<span style="float: left" class="edit_pass1"></span>
						<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
						<button type="submit"  class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		</div>
	</div>