<?php
include('../connect.php');
include('../head.php');
?>

<!DOCTYPE html>
<html>
<body>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#">MSU SULU-SHS</a>
			</div>

			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modal-dept" style="margin-top: 6px;">Log in </button>
				
				<!-- Modal -->
				<div class="modal fade" id="modal-dept">
					<div class="modal-dialog modal-md">
						<div class="modal-content">
							<!-- modal header -->
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h3>Log in</h3>
							</div>
							<!-- modal body -->
							<div class="modal-body">
								<ul class="nav nav-pills">
									<li class="active"><a data-toggle="pill" href="#home">Employee</a></li>
									<li><a data-toggle="pill" href="#menu2">Student</a></li>
									<li><a data-toggle="pill" href="#menu1">Admin</a></li>

								</ul>
								<div class="tab-content">
									<!-- Employee -->
									<div id="home" class="tab-pane fade in active">
										<h3>Employee</h3>
										<form method="post">
											<div class="form-group">
												<input type="text" class="form-control" name="username" placeholder="Employee User Name">
											</div>
											<div class="form-group">
												<input type="password" class="form-control" name="deptPass" placeholder="Password">
											</div>
											<div class="form-group">
												<button class="btn btn-block btn-primary signin-button-department">Log in</button>
												<button class="btn btn-block btn-danger signin-button">Cancel</button>
											</div>
										</form>
									</div>
									<!-- Admin -->
									<div id="menu1" class="tab-pane fade">
										<h3>Admin</h3>
										<form method="post">
											<div class="form-group">
												<input type="text" class="form-control" name="admin_username" placeholder="Username">
											</div>
											<div class="form-group">
												<input type="password" class="form-control" name="adminPass" placeholder="Password">
											</div>
											<div class="form-group">
												<button class="btn btn-block btn-primary signin-button-admin">Log in</button>
												<button class="btn btn-block btn-danger signin-button">Cancel</button>
											</div>
										</form>
									</div>
									<!-- Student -->
									<div id="menu2" class="tab-pane fade">
										<h3>Student</h3>
										<form method="post">
											<div class="form-group">
												<input type="text" class="form-control" name="student_id" placeholder="Student Id">
											</div>
											<div class="form-group">
												<input type="password" class="form-control" name="password" placeholder="Password">
											</div>
											<!-- <div class="form-group">
												<input type="password" class="form-control" name="new_password" placeholder="Password">
											</div>
											<div class="form-group">
												<input type="password" class="form-control" name="new_cpassword" placeholder="Password">
											</div> -->
											<div class="form-group">
												<button class="btn btn-block btn-primary signin-button-employee">Log in</button>
												<button class="btn btn-block btn-danger signin-button">Cancel</button>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> <!-- ENNNNNNNNNND MODAL-->				

			</div><!-- /.navbar-collapse -->
		</div><!-- /.container-fluid -->
	</nav>

	<div class="container">
		<!-- carousel -->
		<div class="row">
			<div id="myCarousel" class="carousel slide" data-ride="carousel" style="padding:20px 20px 20px 20px;">
				<!-- Indicators -->
				<ol class="carousel-indicators">
					<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
					<li data-target="#myCarousel" data-slide-to="1"></li>
					<li data-target="#myCarousel" data-slide-to="2"></li>
					<li data-target="#myCarousel" data-slide-to="3"></li>
				</ol>

				<!-- Wrapper for slides -->
				<div class="carousel-inner" role="listbox">
					<div class="item active">
						<img src="images/Background1.jpg" alt="Chania" width="460" height="200">
					</div>

					<div class="item">
						<img src="images/Background2.jpg" alt="Chania" width="460" height="200">
					</div>

					<div class="item">
						<img src="images/Background3.jpg" alt="Flower" width="460" height="200">
					</div>

					<div class="item">
						<img src="images/Background4.jpg" alt="Flower" width="460" height="200">
					</div>
				</div>

				<!-- Left and right controls -->
				<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
					<span class="icon-prev" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
					<span class="icon-next" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
			</div>
		</div>
		<br />
		<div class="row"> 
			<div class="col-md-5 mv">
				<center><h3>Mission</h3></center>
				<p>We produce highly competitive professionals through proficiency-driven instruction; generate useful research outputs in agro-fishery and applied science and technology, and develop pockets of growth areas through responsive extension services; thereby contributing to the inclusive socio-economic transformation of Sulu and the BARMM.</div>
			<div class="col-md-5 mv">
				<center><h3>Vision</h3></center>
				<p>A World Class academe excelling in Agri-fishery and Applied Science and Technology for the Inclusive Development and Transformation of Sulu and the BARMM.</p>
				</div>
			</div>
		</div>
		<script src="js/jquery-1.12.1.min.js" type="text/javascript"></script>
		<script src="js/bootstrap.min.js" type="text/javascript"></script>
		<script>
			$('.carousel').carousel({
        interval: 3000 //changes the speed
    })
</script>
<script>
	jQuery(function(){
		$('.signin-button-admin').click(function(e){
			e.preventDefault();

			var uname = $.trim($('input[name="admin_username"]').val());
			var pass = $.trim($('input[name="adminPass"]').val());

			$.ajax({
				type: 'POST',
				url: 'loginAdmin.php',
				data: {admin_username: uname, adminPass: pass}
			})
			.done(function(res){
				console.log(res);
				if (res == 1 ){
					window.location.href = "production/admin1.php";
				}else{
					alert('Login failed!');
					$('input[name="admin_username"]').focus();
					$('input').val('');
				}
			});
			}); //Admin

		$('.signin-button-employee').click(function(e){
			e.preventDefault();

			var uname = $.trim($('input[name="username"]').val());
			var pass = $.trim($('input[name="password"]').val());

			$.ajax({
				type: 'POST',
				url: 'logindept.php',
				data: {username: uname, password: pass}
			})
			.done(function(res){
				console.log(res);
				if (res == 1 ){
					window.location.href = "production/designee.php";
				}else{
					alert('Login failed!');
					$('input[name="username"]').focus();
					$('input').val('');
				}
			});
			}); //Employee

		$('.signin-button-faculty').click(function(e){
			e.preventDefault();

			var uname = $.trim($('input[name="student_id"]').val());
			var pass = $.trim($('input[name="password"]').val());

			$.ajax({
				type: 'POST',
				url: 'loginfaculty.php',
				data: {student_id: uname, password: pass}
			})
			.done(function(res){
				console.log(res);
				if (res == 1 ){
					window.location.href = "production/faculty.php";
				}else if (res == 2){
					alert('The system is closed. Please process your clearance manually');
				}else{
					alert('Login failed!');
					$('input[name="student_id"]').focus();
					$('input').val('');
				}
			});
			}); //Student
	});
</script>
</body>
</html>