<?php
include ('connect.php');

$username = $_POST['student_id'];
$password = md5($_POST['password']);

$sql = "SELECT * FROM student WHERE student_id = ? AND password = ?";
$query = $conn->prepare($sql);
$query->execute(array($username,$password));
$row = $query->fetch();
$count = $query->rowCount();

if ($count > 0){
	session_start();
	$_SESSION['id'] = $row['student_id'];
	echo 1;
}else{
	echo 0;
}

?>