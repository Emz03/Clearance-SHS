<div class="modal fade" id="edit1<?php echo $value ['id']?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">Edit <?php echo $value['emp_name']; ?> Profile</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<form action="../edit_employee.php" method="POST">
						<div class="Id">
							<input value = "<?php echo $value['emp_id'];?>" type="hidden" class="form-control" name= "emp_id" placeholder="Employee Id" required>
							<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id"  placeholder="Employee Id" required>
							
						</div>
						<div class="emp_name">
							<label>	Employee Name*</label>
							<input value = "<?php echo $value['emp_name'];?>" class="form-control" name= "emp_name" placeholder="Employee Name" required>
						</div>
						<div class="username">
							<label>UserName</label>
							<input value = "<?php echo $value['username'];?>" class="form-control" name= "username" placeholder="UserName" >
						</div>
						<div class="department">
							<label>Department*</label>
							<input value = "<?php echo $value['department'];?>" class="form-control" name= "department" placeholder="Department" required>
						</div>

						<br>
						
					<div class="modal-footer form-group">
						<div class="row">
							<br />
							<br />
							<button type="button" class="btn btn-danger " data-dismiss="modal"><i class="fa fa-close"></i>Close</button>
							<button type="submit"  class="btn btn-primary ">Save</button>
							 
						</div>
					</div>
				</form>	
			</div>
		</div>
	</div>
</div>